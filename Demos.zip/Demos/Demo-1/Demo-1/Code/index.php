<?php
// ini_set('display_errors', 'On');
	// print("Hello1");

	require('Controller.php');
	$controller = new Controller();
	$controller->run();

	// require('View.php'); // For testing purposes
	// require('Model.php'); // For testing purposes
	// print("Hello");
?>